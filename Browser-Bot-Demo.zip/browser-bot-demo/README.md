# Browser automation example — independent demo

This project runs a small Express site with a Playwright browser bot. It shows that a server can open a controlled source website, fill a form, click Verify, download an **unchanged example image**, and display it inside the main HTML page. **It does not contact Janoshik or verify real reports.**

## Get started (GitHub Codespaces, Replit Shell, or a machine with Node.js)

1. Extract the project ZIP into a folder. If you use GitHub, upload the extracted files into a **private repository**, then select Code > Codespaces > Create codespace.
2. Open Terminal and run:

   ```bash
   npm install
   npx playwright install --with-deps chromium
   npm start
   ```

3. Open the forwarded port **3000**. On a local machine visit `http://localhost:3000`.
4. The prefilled sample is Task number `12345` and Unique key `DEMO-KEY`.
5. Press **Run test bot**. The server visits `/mock-source`, fills the sample values, downloads `/mock-report.svg`, and displays the resulting file.

## Where everything is

- `public/index.html`: frontend form and internal image viewer.
- `server.js`: Express server and Playwright automation.
- `example/mock-source.html`: the controlled source form the bot visits.
- `example/DEMO-report.svg`: the example image which is labelled as a demo.
- `generated/`: copied demo images created by the bot.

## Moving to real-world integrations

This code is deliberately limited to a source page owned by the same project. For a real verification provider, request an approved API or automation arrangement, and follow its access and republication rules. Never show a sample success as a real verification, and clearly identify the original source of genuine reports. Hosting costs and terms still apply even though this project does not consume AI prompt credits.
