'use strict';
const express = require('express');
const { chromium } = require('playwright');
const path = require('node:path');
const fs = require('node:fs/promises');
const { randomUUID } = require('node:crypto');

const app = express();
const port = Number(process.env.PORT) || 3000;
const root = __dirname;
const output = path.join(root, 'generated');

app.use(express.json({ limit: '10kb' }));
app.use(express.static(path.join(root, 'public')));
app.use('/generated', express.static(output, { fallthrough: false }));

// This is deliberately an example page owned by the same project, not a third-party website.
app.get('/mock-source', (req, res) => res.sendFile(path.join(root, 'example', 'mock-source.html')));
app.get('/mock-report.svg', (req, res) => res.download(path.join(root, 'example', 'DEMO-report.svg'), 'DEMO-report.svg'));

app.post('/api/verify-demo', async (req, res) => {
  const task = String(req.body?.task || '').trim();
  const key = String(req.body?.key || '').trim();
  if (task.length > 40 || key.length > 80 || !task || !key) {
    return res.status(400).json({ error: 'Enter a task number and demo key.' });
  }

  let browser;
  try {
    browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
    const page = await browser.newPage({ acceptDownloads: true });
    await page.goto(`http://127.0.0.1:${port}/mock-source`, { waitUntil: 'domcontentloaded' });
    await page.getByLabel('Task number').fill(task);
    await page.getByLabel('Unique key').fill(key);
    await page.getByRole('button', { name: 'Verify demo' }).click();

    const status = await page.locator('#status').innerText();
    if (!status.includes('DEMO MATCH')) {
      return res.status(404).json({ error: 'No match in the demonstration dataset. Try task 12345 and key DEMO-KEY.' });
    }

    const downloadReady = page.waitForEvent('download', { timeout: 15000 });
    await page.getByRole('link', { name: 'Download example image' }).click();
    const download = await downloadReady;
    const savedName = `${randomUUID()}.svg`;
    await fs.mkdir(output, { recursive: true });
    await download.saveAs(path.join(output, savedName));
    res.json({ ok: true, demo: true, reportUrl: `/generated/${savedName}`, message: 'Example image retrieved by the automated browser.' });
  } catch (err) {
    console.error('Demo automation error:', err);
    res.status(500).json({ error: 'Automation failed. Confirm Chromium is installed with: npx playwright install --with-deps chromium' });
  } finally {
    if (browser) await browser.close();
  }
});

app.listen(port, '0.0.0.0', () => console.log(`Demo website available at http://localhost:${port}`));
